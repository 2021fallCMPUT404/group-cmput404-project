Project: social Circle (social network app)

https://cmput404-socialdist-project.herokuapp.com/

What has been done for Part 2 (Update):
Completed (20/42 user stories)

Will review all of our completed parts to ensure they work without any errors for part 3

- rest API implemented for almost all functions.
- Basic athentification to allow other groups to access our data
- UI updated and more friendly for users
- Able to display and access post and user data from other groups
- communicated with group 15 and 03

WORK IN PROGRESS NOT FULLY FUNCTIONING
2021fallCMPUT404, group-cmput404-project



CCID: 
- srezwan
- gortega
- renyu
- qd
- jionghao

CSS and UI still needs work 

Working functions:
- Login
- Register new user
- add post
- edit post
- delete post
- commenting
- friend request
- feed displayed
- share post
- likes on posts and comments
- posting markdown texts
- posting Github activities


Citations:

django documentaion
Source: https://docs.djangoproject.com/en/3.2/

Font Awesome Icons (version 4.7) used
Source: https://fontawesome.com/v4.7/icons/#new

bootstrap Library used
source: https://getbootstrap.com/docs/5.1/getting-started/introduction/

Webseries: Create A Simple Django Blog
'How To Restrict Who Can Make Blog Posts - Django Blog #17' 
Author: 'Codemy.com'
Source:https://www.youtube.com/watch?v=TAH01Iy5AuE&list=PLCC34OHNcOtr025c1kHSPrnP18YPB-NFi&index=17&ab_channel=Codemy.com

Build A Blog Comment Section - Django Blog #33
Author: 'Codemy.com'
Source:https://www.youtube.com/watch?v=hZrlh4qU4eQ&t=1s&ab_channel=Codemy.com

Post Blog Comments - Django Blog #34
Author: 'Codemy.com'
Source: https://www.youtube.com/watch?v=OuOB9ADT_bo&t=1064s&ab_channel=Codemy.com

Bootstrap Grid Examples:
Source: https://getbootstrap.com/docs/4.0/examples/grid/

Bootstrap List-Group Examples:
Source: https://getbootstrap.com/docs/5.1/examples/list-groups/

Django Markdown Tutorial:
Source: https://learndjango.com/tutorials/django-markdown-tutorial

Rest API for GET/POST/PUT/DELETE:
Source: https://www.bezkoder.com/django-rest-api/
